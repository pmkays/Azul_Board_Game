Test checks that the end of game scoring for filled columns is correct.
Each filled column should grant the player a bonus 7 points.
Joe should have 21 points at the end (7*3)