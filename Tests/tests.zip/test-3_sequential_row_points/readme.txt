Test for checking sequential row point allocation.
Initialsave file contains first player with first 4 rows already on their mosaic.
Then adds the last tile to complete that column.
Points added should be 5.