This test was designed to test whether your menu has adequate validation/error handling to deal with invalid input. 

An explanation of the commands in the 12commands.in file is as follows:
3 (valid - credits)
9 (invalid because > 4)
-1 (invalid because negative number)
asd (invalid because string)
 	(invalid because empty line)
/!@#$ (invalid string)
4 (valid - quit)

As this test does not deal with gameplay, there is no supplied initialsave or expectedoutcome file.