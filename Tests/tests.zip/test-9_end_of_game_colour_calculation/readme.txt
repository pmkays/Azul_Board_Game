Test that checks the end of game calculation for colours where all of the tiles have been placed.
Joe should end with 30 points (10*3)