This test was designed to see if you can play a new game, play through it, then load in a game and play a couple of rounds. The test should not produce a segmentation fault anywhere.

When running this test please compile your code and enter the seed of 2:
./assign2 -s 2 < 11commands.in