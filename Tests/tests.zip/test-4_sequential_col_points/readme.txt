Test checks for correct point calculations for sequential columns.
Should have 4 points added from adding the L tile to the last row.