This test is designed to test whether your game can actually end the game and declare the winner once a player has successfully filled in a whole row. 

Note that there is no save command at the bottom of the commands.in file, as the game should finish and the winner announced. Therefore, each group would have different presentations for the end of game.  

There is also no expectedoutcome.save file for this same reason. 