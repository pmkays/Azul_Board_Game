test checks the correct point calculation of adding an isolated tile to the mosaic.
Also, this test shows that points don't go below 0.