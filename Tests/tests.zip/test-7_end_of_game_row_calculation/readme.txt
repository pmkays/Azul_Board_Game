Test checks that the end of game scoring works correctly for the rows.
Each filled row should grant the player an extra 2 points.

The end of game points should be
21 for joe,
13 for moe