This test checks that sequential rows and sequential columns are counted correctly
when adding a tile to the mosaic. Player one should get 9 points, 5 from sequential rows
and 4 from sequential cols.